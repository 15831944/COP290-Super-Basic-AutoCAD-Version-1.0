#ifndef MY_FUNCS
#define MY_FUNCS
#define PI 3.1415926
#include <string>	
	
	void wait_for_key ();
	int display_3d(std::string file_name);
	void orthographic_display(std::string file_name);
	void frontview(std::string file_name);

#endif