#ifndef FILE_OPERATORS
#define FILE_OPERATORS
#include <string>

	void rotate(std::string file_name,float alpha,float beta, float gamma);
	void copy_file(std::string input_file, std::string copied_file);
	void twod_to_threed(std::string input_file, std::string threed_file);


#endif
