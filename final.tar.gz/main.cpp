#include <math.h>
#include <stdio.h>
#include <iostream>
#define PI 3.1415926
#include "my_display.hpp"
#include "file_operators.hpp"

using namespace std;

int main(){
	//cout<<"im a superstar"<<endl;

	string state="start";
	string user_input;
	string active="active.txt";
	string temporary="temporary.txt";
	float alpha,beta,gamma;
	float a,b,c;
	float normalise;
	//states can be start, 
	while(true){

		//cin<<user_input;
		//if(user_input=="exit") break;
		cout<<"\n";
		if(state=="start"){
			cout<<"		"<<"Welcome to super_basic_autocad version 1.0"<<endl;
			cout<<"		"<<"Would you like to display a 3d file or a 2d one"<<endl;
			cout<<"		"<<"For 3d enter 3d and for 2d enter 2d"<<endl;
			cout<<"		";
			//cin>>user_input;
			while(true){
				cin>>user_input;
				cin.get();
				if(user_input=="3d"){state="3d";break;} 
				else if(user_input=="2d"){state="2d";break;} 
				else if(user_input=="home"){
					cout<<"		"<<"this is home, choose an option among the above"<<"\n\n";
				}
				else if(user_input=="quit"){
					state="exit";break;
				}
				else{
					cout<<"		"<<"invalid input, please try again."<<"\n";
					cout<<"		";
				}
			}

		}
		else if(state=="exit"){
			cout<<"		"<<"bbye"<<endl;
			break;
		}
		else if(state=="3d"){
			cout<<"		"<<"Specify the file name"<<"\n";
			cout<<"		";
			cin>>user_input;
			cin.get();
			//thank you prakhar

			copy_file(user_input,active);
			display_3d(active);
			state="options_for_3d";
			//cin>>user_input;
		}
		// else if(state=="display_3d"){
		// 	display_3d(active);
		// }
		// else if(state=="display_2d_front"){
		// 	front_view(active);
		// 	state="options_for_3d";			
		// }
		// else if(){

		// }
		else if(state=="2d"){
			cout<<"		"<<"Specify the file name"<<"\n";
			cout<<"		";
			cin>>user_input;;
			cin.get();

			copy_file(user_input,temporary);
			//cin.get();

			twod_to_threed(user_input,active);
			//cin.get();

			orthographic_display(active);

			state="options_for_2d";
		}

		else if(state=="options_for_2d"){
			cout<<"		"<<"What would you like to do with this 2d object?"<<endl;
			cout<<"		"<<"View it again or convert it to a 3d one"<<endl;
			cout<<"		"<<"Type display or convert"<<endl;
			cout<<"		";

			while(true){
				cin>>user_input;
				if(user_input=="display"){
					state="display_2dfile";break;
				}
				else if(user_input=="convert"){
					state="options_for_3d";
					cout<<"		"<<"Converted successfully"<<endl;
					cout<<"		";
					break;
				}
				else if(user_input=="home"){
					state="start";break;
				}
				else if(user_input=="quit"){
					state="exit";break;
				}
				else{
					cout<<"		"<<"invalid input, please try again."<<"\n";
					cout<<"		";
				}
			}


		}
		else if(state=="display_2dfile"){
			cin.get();
			orthographic_display(active);
			state="options_for_2d";
		}
		else if(state=="options_for_3d"){
			cout<<"		"<<"What would you like to do with this 3d object?"<<endl;
			cout<<"		"<<"View isometrically, orthographic projections or view along a specific angle"<<endl;
			cout<<"		"<<"Type iso,ortho or compress respectively for your choice"<<endl;
			cout<<"		";
			
			while(true){
				cin>>user_input;
				if(user_input=="iso"){
					state="iso";break;
				}
				else if(user_input=="ortho"){
					state="ortho";break;
				}
				else if(user_input=="compress"){
					state="compress";break;
				}
				else if(user_input=="home"){
					state="start";break;
				}
				else if(user_input=="quit"){
					state="exit";break;
				}
				else if(user_input=="rotate"){
					state="rotate";break;
				}
				else if(user_input=="display"){
					cin.get();
					display_3d(active);
					state="options_for_3d";
				}
				else{
					cout<<"		"<<"invalid input, please try again."<<"\n";
					cout<<"		";
				}
			}
				

		}
		else if(state=="rotate"){	
			cout<<"		"<<"Specify the angles."<<endl;
			cout<<"		";
			cin>>alpha>>beta>>gamma;
			cin.get();
			rotate(active,alpha,beta,gamma);
			//display_3d(active);
			state="options_for_3d";
		}
		else if(state=="iso"){
			//given a viewing angle of 1,1,1 we want to view its front view only
			copy_file(active,temporary);
			rotate(temporary,0,35.264,-45);
			//cout<<"		"<<"im a cow"<<endl;
			cout<<"		";
			cin.get();
			frontview(temporary);
			state="options_for_3d";
		}
		else if(state=="ortho"){
			cin.get();
			orthographic_display(active);
			state="options_for_3d";
		}
		else if(state=="compress"){
			cout<<"		"<<"Specify the viewing angle by giving me a,b and c of the vector ai + bj + ck we are viewing this object"<<endl;
			cout<<"		";
			cin>>a>>b>>c;
			normalise= sqrt(b*b + a*a);
			beta=atan(c/normalise);
			beta= (beta*180)/PI;
			gamma= -1*atan(b/a);
			gamma= (gamma*180)/PI;
			cin.get();
			copy_file(active,temporary);
			rotate(temporary,0,beta,gamma);
			frontview(temporary);
			state="options_for_3d";


		}
		else{
			//crash
			cout<<"something went wrong\n";
			break;
		}

		//this is where the continuous asking of inputs ends


	}

	
}
